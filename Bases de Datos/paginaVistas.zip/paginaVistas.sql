-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.1.19-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win32
-- HeidiSQL Versión:             10.1.0.5464
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Volcando estructura de base de datos para paginavistas
CREATE DATABASE IF NOT EXISTS `paginavistas` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;
USE `paginavistas`;

-- Volcando estructura para vista paginavistas.csspageview
-- Creando tabla temporal para superar errores de dependencia de VIEW
CREATE TABLE `csspageview` (
	`name` VARCHAR(100) NOT NULL COLLATE 'utf8_unicode_ci',
	`path` VARCHAR(30) NOT NULL COLLATE 'utf8_unicode_ci',
	`pageName` VARCHAR(30) NOT NULL COLLATE 'utf8_unicode_ci'
) ENGINE=MyISAM;

-- Volcando estructura para vista paginavistas.jspageview
-- Creando tabla temporal para superar errores de dependencia de VIEW
CREATE TABLE `jspageview` (
	`pageName` VARCHAR(30) NOT NULL COLLATE 'utf8_unicode_ci',
	`path` VARCHAR(30) NOT NULL COLLATE 'utf8_unicode_ci',
	`name` VARCHAR(100) NOT NULL COLLATE 'utf8_unicode_ci',
	`orderFileJs` TINYINT(1) NOT NULL
) ENGINE=MyISAM;

-- Volcando estructura para vista paginavistas.linkpageview
-- Creando tabla temporal para superar errores de dependencia de VIEW
CREATE TABLE `linkpageview` (
	`pageName` VARCHAR(30) NOT NULL COLLATE 'utf8_unicode_ci',
	`link` VARCHAR(200) NOT NULL COLLATE 'utf8_unicode_ci'
) ENGINE=MyISAM;

-- Volcando estructura para vista paginavistas.metapageview
-- Creando tabla temporal para superar errores de dependencia de VIEW
CREATE TABLE `metapageview` (
	`pageName` VARCHAR(30) NOT NULL COLLATE 'utf8_unicode_ci',
	`meta` VARCHAR(200) NOT NULL COLLATE 'utf8_unicode_ci'
) ENGINE=MyISAM;

-- Volcando estructura para vista paginavistas.pageviewtitle
-- Creando tabla temporal para superar errores de dependencia de VIEW
CREATE TABLE `pageviewtitle` (
	`pageName` VARCHAR(30) NOT NULL COLLATE 'utf8_unicode_ci',
	`title` VARCHAR(100) NOT NULL COLLATE 'utf8_unicode_ci'
) ENGINE=MyISAM;

-- Volcando estructura para procedimiento paginavistas.getBody
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `getBody`(IN `pageName` VARCHAR(30), OUT `retorno` VARCHAR(5000))
    NO SQL
BEGIN

SET @idPagina = (SELECT `codePage` FROM pagina.`page` WHERE pagina.`page`.`pageName` = pageName);

CALL pagina.get_Body(@idPagina,retorno);

END//
DELIMITER ;

-- Volcando estructura para procedimiento paginavistas.getCssAll
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `getCssAll`(IN `pageName` VARCHAR(30))
    NO SQL
BEGIN

SELECT csspageview.name as name,csspageview.path as path FROM `csspageview` WHERE csspageview.pageName = pageName;

END//
DELIMITER ;

-- Volcando estructura para procedimiento paginavistas.getJsAll
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `getJsAll`(IN `pageName` VARCHAR(30))
    NO SQL
BEGIN

SELECT jspageview.path as path, jspageview.name as name FROM jspageview WHERE jspageview.pageName = pageName ORDER BY jspageview.orderFileJs;


END//
DELIMITER ;

-- Volcando estructura para procedimiento paginavistas.getLinkAll
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `getLinkAll`(IN `pageName` VARCHAR(30), OUT `retorno` VARCHAR(1000))
    NO SQL
BEGIN

DECLARE linkTemp varchar(1000) DEFAULT "";
DECLARE cursorLink CURSOR FOR (SELECT linkpageview.link as link FROM linkpageview where linkpageview.pageName = pageName);

DECLARE CONTINUE HANDLER FOR NOT FOUND SET @fin = true;
SET @fin = false;

OPEN cursorLink;

FETCH cursorLink INTO linkTemp;
SET retorno = linkTemp;
WHILE @fin = false DO 
	
SET retorno = concat(retorno," ",linkTemp);
FETCH cursorLink INTO linkTemp;
END WHILE;
CLOSE cursorLink;
 
 
 END//
DELIMITER ;

-- Volcando estructura para procedimiento paginavistas.getMetaAll
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `getMetaAll`(IN `pageName` VARCHAR(30), OUT `retorno` VARCHAR(2000))
    NO SQL
BEGIN

DECLARE fin boolean DEFAULT false;
DECLARE miLeyenda varchar (2000) DEFAULT "";
DECLARE cursorLinks CURSOR FOR SELECT metapageview.meta FROM metapageview WHERE metapageview.pageName = pageName;

DECLARE CONTINUE HANDLER FOR NOT FOUND SET fin = true;

SET retorno = "";

OPEN cursorLinks;
FETCH cursorLinks INTO retorno;
WHILE fin = false DO
	SET retorno = concat(retorno," ",miLeyenda);
	FETCH cursorLinks INTO miLeyenda;
END WHILE;
CLOSE cursorLinks;
 
 
 END//
DELIMITER ;

-- Volcando estructura para procedimiento paginavistas.getTitle
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `getTitle`(IN `pageName` VARCHAR(30), OUT `retorno` VARCHAR(30))
    NO SQL
BEGIN

SELECT pageviewtitle.title INTO retorno FROM pageviewtitle WHERE pageviewtitle.pageName = pageName;

END//
DELIMITER ;

-- Volcando estructura para vista paginavistas.csspageview
-- Eliminando tabla temporal y crear estructura final de VIEW
DROP TABLE IF EXISTS `csspageview`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `csspageview` AS select `pagina`.`filecss`.`nameFileCss` AS `name`,`pagina`.`filecss`.`pathFileCss` AS `path`,`pagina`.`page`.`pageName` AS `pageName` from ((`pagina`.`filecss` join `pagina`.`pagecss`) join `pagina`.`page`) where ((`pagina`.`filecss`.`idFileCss` = `pagina`.`pagecss`.`IdFileCss`) and (`pagina`.`pagecss`.`idPage` = `pagina`.`page`.`codePage`)) ;

-- Volcando estructura para vista paginavistas.jspageview
-- Eliminando tabla temporal y crear estructura final de VIEW
DROP TABLE IF EXISTS `jspageview`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `jspageview` AS select `pagina`.`page`.`pageName` AS `pageName`,`pagina`.`filejs`.`pathFileJs` AS `path`,`pagina`.`filejs`.`fileJs` AS `name`,`pagina`.`pagejs`.`orderFileJs` AS `orderFileJs` from ((`pagina`.`page` join `pagina`.`pagejs`) join `pagina`.`filejs`) where ((`pagina`.`filejs`.`IdFileJs` = `pagina`.`pagejs`.`IdFileJs`) and (`pagina`.`page`.`codePage` = `pagina`.`pagejs`.`idPage`)) ;

-- Volcando estructura para vista paginavistas.linkpageview
-- Eliminando tabla temporal y crear estructura final de VIEW
DROP TABLE IF EXISTS `linkpageview`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `linkpageview` AS select `pagina`.`page`.`pageName` AS `pageName`,`pagina`.`linkhref`.`linkHref` AS `link` from ((`pagina`.`page` join `pagina`.`linkhref`) join `pagina`.`pagelinkhref`) where ((`pagina`.`linkhref`.`IdLinkHref` = `pagina`.`pagelinkhref`.`IdLinkHref`) and (`pagina`.`page`.`codePage` = `pagina`.`pagelinkhref`.`idPage`)) ;

-- Volcando estructura para vista paginavistas.metapageview
-- Eliminando tabla temporal y crear estructura final de VIEW
DROP TABLE IF EXISTS `metapageview`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `metapageview` AS select `pagina`.`page`.`pageName` AS `pageName`,`pagina`.`metadata`.`ValueMetaData` AS `meta` from ((`pagina`.`page` join `pagina`.`metadata`) join `pagina`.`pagemetadata`) where ((`pagina`.`metadata`.`idMetaData` = `pagina`.`pagemetadata`.`idMetaData`) and (`pagina`.`page`.`codePage` = `pagina`.`pagemetadata`.`idPage`)) ;

-- Volcando estructura para vista paginavistas.pageviewtitle
-- Eliminando tabla temporal y crear estructura final de VIEW
DROP TABLE IF EXISTS `pageviewtitle`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `pageviewtitle` AS select `pagina`.`page`.`pageName` AS `pageName`,`pagina`.`page`.`titlePage` AS `title` from `pagina`.`page` ;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
